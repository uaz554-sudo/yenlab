# 顏究所 YEN LAB AERO — GitHub Pages 網站

這是一個可部署到 GitHub Pages 的 Jekyll 靜態新聞網站起始專案。

## 目前包含
- 響應式首頁與新聞卡片
- 航空動態、航線與航權、機隊、哩程、信用卡與飯店會員分類頁
- 獨立新聞內頁
- 基本 SEO、RSS feed 與 sitemap（由 GitHub Pages/Jekyll 外掛產生）
- 手機版導覽選單
- 示範文章，可編輯或刪除

## 1. 上傳到 GitHub
1. 在 GitHub 建立一個 **公開** repository，建議命名為 `yenlabaero`。
2. 將 ZIP 解壓縮。
3. 把解壓後的所有檔案與資料夾上傳到 repository 根目錄（不要把整個資料夾再包一層）。
4. 到 repository 的 **Settings → Pages**。
5. 在 Build and deployment 選擇 **Deploy from a branch**，Branch 選 `main`，資料夾選 `/ (root)`，按 Save。
6. 等待 Actions/Pages 建置完成，再開啟 GitHub 顯示的網站網址。

## 2. 綁定 yenlabaero.com
網站先成功發佈後再綁定：
1. Repository → Settings → Pages → Custom domain，填入 `yenlabaero.com` 並儲存。
2. 到 Namecheap 的 Advanced DNS，依 GitHub Pages 官方文件設定 apex domain 的 A/AAAA 記錄，以及 `www` 的 CNAME 記錄。
3. DNS 生效後回到 Pages 設定，啟用 Enforce HTTPS（可用時再勾選）。

DNS 的實際設定請以 GitHub Pages 官方文件為準：
https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

## 3. 新增新聞文章
在 `_posts` 建立檔案，檔名格式為 `YYYY-MM-DD-英文短網址.md`，例如：
`2026-10-12-cathay-transfer-bonus.md`

貼上以下格式：

---
title: "文章標題"
date: 2026-10-12 10:00:00 +0800
categories: [miles]
category_label: "哩程與轉點"
description: "簡短摘要，適合搜尋結果與首頁顯示。"
source_url: "https://example.com/official-announcement"
---

文章正文寫在這裡。使用 Markdown 標題：

## 活動內容
段落文字……

## 注意事項
段落文字……

### 可用分類 key
- `aviation`：航空動態
- `routes`：航線與航權
- `fleet`：機隊與航空公司
- `miles`：哩程與轉點
- `cards-hotels`：信用卡與飯店會員

## 4. 新增封面圖片
將圖片放進 `assets/images/`，文章 front matter 加上：
`cover: /assets/images/your-photo.jpg`
`cover_alt: "圖片的替代文字"`

請只使用自己拍攝、已獲授權或可合法使用的圖片。若沒有封面圖，網站會顯示品牌樣式的預設圖。

## 5. 目前限制
- GitHub Pages 是靜態網站：沒有內建登入後台、資料庫或線上文章編輯器。
- 新增文章的方式是編輯 Markdown 檔案並推送到 GitHub。
- 未來要升級後台，可保留此網站前端與文章格式，再接入 CMS/API；需要另外規劃權限、安全性與資料儲存。
- 本專案未在你的 GitHub 帳號或網域上自動部署；你仍需完成上述上傳與設定。
